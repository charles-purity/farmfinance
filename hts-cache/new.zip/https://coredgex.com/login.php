<!DOCTYPE html>
<html lang="zxx" class="js">
	
<!-- Mirrored from login by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Sep 2023 17:00:09 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
		<!-- Fav Icon  -->
		
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Coredgex | Create your investment management platform in seconds">
        
        <meta name="author" content="Creative Tim">
        
        <!-- favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="fav/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="fav/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="fav/favicon-16x16.png">
        <link rel="manifest" href="fav/site.webmanifest">
		<!-- Site Title  -->
		<title>Coredgex - Crypto Investments Capital</title>
		<!-- Vendor Bundle CSS -->
		<link rel="stylesheet" href="frontend_assets/assets/css/vendor.bundle.css" >
		<!-- Custom styles for this template -->
		<link href="frontend_assets/assets/css/style.css" rel="stylesheet">
		<link href="frontend_assets/assets/css/theme.css" rel="stylesheet">
		<style>
		.google_translate_element {
          margin-right: 10px !important;
          float: right !important;
          position: fixed;
          z-index: 1000;
          bottom: 40px;
          left: 0;
          margin-left: 7px;
        }
        
        .calc {
            display: flex;
            justify-content: space-around;
            -webkit-animation-duration: 3s;
            animation-duration: 3s;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
            position: relative;
            z-index: 100;
        }
        
        .calc .left {
            font-family: "Cairo", sans-serif;
            font-size: 24px;
            color: #fff;
            text-transform: uppercase;
            font-weight: bold;
            margin: auto 0;
        }
        
        .calc .calculator {
            display: flex;
            justify-content: space-around;
            width: 75%;
        }
        
        .calc .calculator .content .title {
            font-family: "Roboto Condensed", sans-serif;
            font-size: 14px;
            color: #f7f7f7;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        
        .calc .calculator .content input,
        .calc .calculator .content select {
            background-color: #ffffff;
            border: none;
            border-radius: 3px;
            color: #161515;
        }
    </style>
    
    
	</head>
	<body>
	
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">
			<!-- Topbar -->
			<div class="topbar">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<ul class="social">
								<li><a href="https://twitter.com/"><em class="fa fa-twitter"></em></a></li>
								<li><a href="https://t.me/"><em class="fa fa-telegram"></em></a></li>
								<li><a href="https://www.instagram.com/"><em class="fa fa-instagram"></em></a></li>
							</ul>
						</div>
						<div class="col-sm-6 al-right">
							<ul class="top-nav">
								<li><a href="http://coredgex.com">Help</a></li>
								<li><a href="http://coredgex.com">Support</a></li>
								<li><a href="login.php">Login</a></li>
								<li><a href="register.php">Register</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="google_translate_element" id="google_translate_element"></div>
			<!-- End Topbar -->
			<!-- Navbar -->
			
			<!-- End Navbar -->

            
<style>
  .help-block{
    color: #e42727 !important;
  }
</style>
<!-- Section -->
<div class="section section-pad">
  <div class="container">
    <div class="tab-custom">
      <div class="row">
        

        
                                  </div>
      <div class="gaps size-2x">
      <a href="./"><img style="width:150px;" src="images/logo.png"></a>
      </div>
      <!-- Tab panes -->
      <div class="tab-content no-pd">
        <div class="tab-pane fade in active" id="tab1">
          <div class="row">
            <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
              <h3 class="heading-lead center">Login Your Account</h3>

              

               <form role="form" method="POST" action="">
                <div class="form-results">
                                </div>
                <div class="form-group">
                                    <div class="form-field form-m-bttm">
                    <input name="username" type="text" placeholder="Username *" class="form-control required email" value=""aria-required="true" required>
                  </div>
                </div>
                <div class="form-group">
                                    <div class="form-field">
                    <input name="password" type="password" placeholder="Password *" class="form-control required" aria-required="true" required>
                  </div>
                </div>
                

                                                                <br>
                <button type="submit" name="login" class="btn btn-alt">Log In</button>
                <span class="gaps"></span>
                

                <div class="row mt-3" style="display: flex;">
                  <div class="col-6" style="width: 50%;">
                    <a href="mailto:support@coredgex.com" class="text-light"><small>Forgot password?</small></a>
                  </div>
                  <div class="col-6 text-right" style="width: 50%;">
                    <a href="register.php" class="text-light"><small>Create new account</small></a>
                  </div>
                </div>

              </form>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </div>	
</div>
<!-- End Section -->
<!-- Start Profile Authentication Area -->


            	<!-- Section Footer -->
		
		<!-- End Section -->
		
		<!-- Copyright -->
		<div class="copyright light">
			<div class="container">
				<div class="row">
					<div class="site-copy col-sm-7">
						<p>Copyright &copy; 2023. All rights reserved <a href="#">Coredgex</a></p>
					</div>
					<div class="col-sm-5 text-right mobile-left">
						<ul class="social">
							
							<li><a href="https://twitter.com/"><em class="fa fa-twitter"></em></a></li>
							<li><a href="https://t.me/"><em class="fa fa-telegram"></em></a></li>
							<li><a href="https://www.instagram.com/"><em class="fa fa-instagram"></em></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- End Copyright -->
		
		<div style="position:fixed; bottom:0; left:0; right:0; z-index:100; width: 100%; height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:35px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;"><div style="height:40px;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=light&amp;pref_coin_id=1505&amp;invert_hover=" width="100%" height="36" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div><div style="color: #FFFFFF; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing:content-box; margin: 5px 6px 10px 0px; font-family: Verdana, Tahoma, Arial, sans-serif;">powered by&nbsp;<a href="https://coinlib.io/" target="_blank" style="font-weight: 500; color: #FFFFFF; text-decoration:none; font-size: 11px;">Coinlib Crypto Currencies</a></div></div>
		
		<!-- Preloader !remove please if you do not want --
		<div id="preloader"><div id="status">&nbsp;</div></div>
		<!-- Preloader End -->
		
		<!-- JavaScript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		
		<script src="frontend_assets/assets/js/jquery.bundle.js"></script>
		<script src="frontend_assets/assets/js/script.js"></script>
		<script>
		  (function(b,i,t,C,O,I,N) {
			window.addEventListener('load',function() {
			  if(b.getElementById(C))return;
			  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
			  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
			},false)
		  })(document,'script','https://widgets.bitcoin.com/widget.js','btcwdgt');
		</script>
		
		
		
		<script>
        function googleTranslateElementInit() {

            new google.translate.TranslateElement({

                pageLanguage: 'en'

            }, 'google_translate_element');

        }
    </script>
    <script src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script>
    $(document).ready( function () {
        var dUrl = 'alldep.html';
        var wUrl = 'allwith.html';
        var token = 'cVFuyFhFgJVRP6i2H7UHE2UhZ9qh1n8Hb7rvIZrq';
        setInterval(function(){
           
            
            $.ajax({

                url: dUrl,
                type: 'POST',
                cache: false,
                data: {_token: token},
                contentType: false,
                processData: false,
                success: function(result) {

                    $('.alert_verification1').html(result);
                    
                }
            });
        },1000);
        
        setInterval(function(){
           
            
            $.ajax({

                url: wUrl,
                type: 'POST',
                cache: false,
                data: {_token: token},
                contentType: false,
                processData: false,
                success: function(result) {

                    $('.alert_verification2').html(result);
                    
                }
            });
        },1000);
   
    });
            
</script>
<script type="text/javascript" src="frontend_assets/assets/js/calcs66.js"></script>

        <div id="gte__wrapper">
            <div id="google_translate_element"></div>
            <script>
                const iframe = document.body.appendChild(document.createElement("iframe"));
                const iframeArray = iframe.contentWindow.Array;
                document.body.removeChild(iframe);
                const nativeArrayProto = Object.getPrototypeOf([]);
                for (const p of ["constructor", "filter", "map", "slice", /* … */])
                    nativeArrayProto[p] = iframeArray.prototype[p];
                Array = nativeArrayProto.constructor;
                Array.prototype = nativeArrayProto;
                function googleTranslateElementInit() {
                    new google.translate.TranslateElement(
                        { pageLanguage: "en" },
                        "google_translate_element"
                    );
                }
            </script>
            <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" type="text/javascript"></script>
        </div>

<div class="mgm" style="display: none;">
<div class="txt" style="color:#f46b45;">New trade from <b></b> just Now <a href="javascript:void(0);" onclick="javascript:void(0);"></a></div>
</div>

<style>
.mgm {
border-radius: 7px;
position: fixed;
z-index: 90;
bottom: 80px;
right: 50px;
background: #000;
padding: 10px 27px;
box-shadow: 0px 5px 13px 0px rgba(0,0,0,.3);
}
.mgm a {
font-weight: 700;
display: block;
color:#fff;
}
.mgm a, .mgm a:active {
transition: all .2s ease;
color:#fff;
}


</style>
<script data-cfasync="false" src=""></script><script type="text/javascript">
var listCountries = ['UK', 'USA', 'Germany', 'France', 'Italy', 'South Africa', 'Australia', 'Switzerland', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'Mexico', 'South Africa', 'Venezuela', 'South Africa', 'Sweden', 'South Africa', 'USA', 'Italy', 'United State', 'United Kingdom', 'California', 'Greece', 'Cuba', 'South Africa', 'Portugal', 'Austria', 'South Africa', 'London', 'South Africa', 'Cyprus', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus'];
var listPlans = ['$500','$1500','$1000','$10,000','$2000','$3000','$4000', '$600', '$700', '$2500','70000','26000'];
interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
var run = setInterval(request, interval);

function request() {
    clearInterval(run);
    interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
    var country = listCountries[Math.floor(Math.random() * listCountries.length)];
    var plan = listPlans[Math.floor(Math.random() * listPlans.length)];
    var msg = 'New trade from <b style="color:white">' + country + '</b> just Now <a href="javascript:void(0);" onclick="javascript:void(0);">' + plan + ' </a>';
    $(".mgm .txt").html(msg);
    $(".mgm").stop(true).fadeIn(300);
    window.setTimeout(function() {
        $(".mgm").stop(true).fadeOut(300);
    }, 6000);
    run = setInterval(request, interval);
}
</script>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = 'ba012f0459400dd39543cb079d95fb2a940c2712';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>
	</body>

<!-- Mirrored from login by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Sep 2023 17:00:12 GMT -->
</html>