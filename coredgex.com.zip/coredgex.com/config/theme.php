<?php
return [
    'deepblack' => [
        'title' => 'Gold Black',
        'path' => 'assets/uploads/theme/deepblack.png',
    ],
    'deepblue' => [
        'title' => 'Deep Blue',
        'path' => 'assets/uploads/theme/deepblue.png',
    ],
    'darkpurple' => [
        'title' => 'Dark Purple',
        'path' => 'assets/uploads/theme/darkpurple.png',
    ],
    'lightyellow' => [
        'title' => 'Light Yellow',
        'path' => 'assets/uploads/theme/lightyellow.png',
    ],
    'lightpink' => [
    'title' => 'Light Pink',
    'path' => 'assets/uploads/theme/lightpink.png',
    ],
    'lightorange' => [
        'title' => 'Light Orange',
        'path' => 'assets/uploads/theme/lightorange.png',
    ]
];
