<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'investment, HYIP, HYIP investment, hyip website, invest, investment, Investment Management system, investment script, Bug Finder, bug-finder, bugfinder.net, bugfinder',
  'meta_description' => 'Hyip Pro,  A Modern Hyip Investmet Platform',
  'social_title' => 'Hyip Pro,  A Modern Hyip Investmet Platform',
  'social_description' => 'Hyip Pro,  A Modern Hyip Investmet Platform',
);